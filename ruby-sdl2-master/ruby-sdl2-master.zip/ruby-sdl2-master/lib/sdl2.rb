require 'sdl2_ext'
require 'sdl2/version'

